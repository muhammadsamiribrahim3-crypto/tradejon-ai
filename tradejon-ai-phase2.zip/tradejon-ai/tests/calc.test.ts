import { describe, expect, it } from 'vitest';
import { assessStage, drawdownPct, riskAmount, stopDistance } from '../src/lib/calc';

describe('calc', () => {
  it('risk amount', () => {
    expect(riskAmount(5000, 1)).toBe(50);
    expect(riskAmount(0, 1)).toBeNull();
    expect(riskAmount(5000, 101)).toBeNull();
    expect(riskAmount(NaN, 1)).toBeNull();
  });
  it('stop distance', () => {
    expect(stopDistance(1.085, 1.082)).toBeCloseTo(0.003, 6);
    expect(stopDistance(1, 1)).toBeNull();
  });
  it('drawdown', () => {
    expect(drawdownPct(5000, 4500)).toBe(10);
    expect(drawdownPct(5000, 5200)).toBe(0);
    expect(drawdownPct(0, 1)).toBeNull();
  });
  it('assessment', () => {
    expect(assessStage(['yes', '', 'yes'])).toBeNull();
    expect(assessStage(['no', 'no', 'no'])?.stage).toBe('Beginner');
    expect(assessStage(['yes', 'yes', 'yes'])?.stage).toBe('Provisional advanced');
  });
});

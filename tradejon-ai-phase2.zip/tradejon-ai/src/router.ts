import { $ } from './lib/dom';

const titles: Record<string, string> = {
  dashboard: 'Good trading starts with a plan.', tutor: 'Learn the market, step by step.',
  markets: 'Build alerts around your plan.', risk: 'Protect your capital first.',
  journal: 'Learn from every trade.', demo: 'Practice without risking real money.',
  prop: 'Keep your rules in view.', settings: 'Make TradeJon AI yours.',
};

export function go(page: string, push = true): void {
  if (!titles[page]) page = 'dashboard';
  document.querySelectorAll<HTMLElement>('.page').forEach((p) => p.classList.toggle('active', p.id === page));
  document.querySelectorAll<HTMLElement>('.nav button[data-page]').forEach((b) => {
    const on = b.dataset.page === page;
    b.classList.toggle('active', on);
    if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
  });
  const h1 = $('pageTitle');
  h1.textContent = titles[page];
  document.title = 'TradeJon AI — ' + page.charAt(0).toUpperCase() + page.slice(1);
  $('sidebar').classList.remove('open');
  if (push) {
    if (location.hash !== '#' + page) location.hash = page;
    window.scrollTo(0, 0);
    h1.tabIndex = -1;
    h1.focus({ preventScroll: true });
  }
}

export function initRouter(): void {
  document.querySelectorAll<HTMLElement>('[data-page]').forEach((b) => b.addEventListener('click', () => go(b.dataset.page ?? 'dashboard')));
  document.querySelectorAll<HTMLElement>('[data-goto]').forEach((b) => b.addEventListener('click', () => go(b.dataset.goto ?? 'dashboard')));
  $('menuBtn').addEventListener('click', () => $('sidebar').classList.toggle('open'));
  document.addEventListener('click', (e) => {
    if (!(e.target as Element).closest('#sidebar,#menuBtn')) $('sidebar').classList.remove('open');
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') $('sidebar').classList.remove('open'); });
  window.addEventListener('hashchange', () => go(location.hash.slice(1), false));
  if (location.hash) go(location.hash.slice(1), false);
}

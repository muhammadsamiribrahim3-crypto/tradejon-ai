export const LESSONS: Record<string, string> = {
  'Market structure': 'Start with swing highs and lows. Mark higher highs/higher lows or lower highs/lower lows, then identify when structure changes. Practise on historical charts before risking money.',
  'Support and resistance': 'Mark zones where price reacted more than once. Treat them as areas, not perfect lines. Wait for a defined confirmation and record whether it works over many examples.',
  'Supply and demand': 'Identify strong moves away from a base, then test how price behaves when revisiting that area. Avoid assuming every zone will hold.',
  'Risk management': 'Choose invalidation before entry. Calculate money at risk first, set a daily stop, and never increase size just to recover a loss.',
  'Trading psychology': 'Write down your plan before the session. Track fear, FOMO and revenge trading. Take a break after breaking a rule.',
  'Backtesting a strategy': 'Write exact entry, stop, exit and session rules. Test a meaningful sample, include costs, and record win rate, average win/loss and drawdown.',
  'Prop firm rules': 'Read the exact agreement: daily loss, total drawdown, news rules, holding restrictions and prohibited execution. Track equity, not only balance.',
};

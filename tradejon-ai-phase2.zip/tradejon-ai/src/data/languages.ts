export const LANGS: ReadonlyArray<readonly [string, string]> = [
  ['en', 'English'], ['ha', 'Hausa'], ['ar', 'العربية'], ['fr', 'Français'], ['es', 'Español'],
  ['pt', 'Português'], ['zh', '中文'], ['hi', 'हिन्दी'], ['ur', 'اردو'], ['bn', 'বাংলা'],
  ['ru', 'Русский'], ['ja', '日本語'], ['ko', '한국어'], ['tr', 'Türkçe'], ['id', 'Indonesia'],
  ['sw', 'Kiswahili'], ['yo', 'Yorùbá'], ['ig', 'Igbo'], ['fa', 'فارسی'], ['de', 'Deutsch'],
];
export const RTL = ['ar', 'ur', 'fa'];

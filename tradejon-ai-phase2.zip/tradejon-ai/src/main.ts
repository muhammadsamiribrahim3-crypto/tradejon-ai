import './styles.css';
import { $ } from './lib/dom';
import { initRouter } from './router';
import { refreshDashboard } from './modules/dashboard';
import { initTutor } from './modules/tutor';
import { initMarkets } from './modules/markets';
import { initRisk } from './modules/risk';
import { initJournal } from './modules/journal';
import { initDemo } from './modules/demo';
import { initProp } from './modules/prop';
import { initSettings } from './modules/settings';

// Accessibility: link each label to its control; announce results to screen readers.
document.querySelectorAll<HTMLElement>('.field').forEach((f) => {
  const l = f.querySelector('label'), i = f.querySelector('input,select');
  if (l && i?.id) l.htmlFor = i.id;
});
document.querySelectorAll('.result').forEach((r) => r.setAttribute('aria-live', 'polite'));

initRouter(); initSettings(); initTutor(); initMarkets(); initRisk(); initJournal(); initDemo(); initProp();
refreshDashboard();
$('app-version').textContent = 'v0.2.0 · Phase 2 · local-only prototype';

// Service worker only in production builds (it would cache stale files during development).
if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', () => { navigator.serviceWorker.register(import.meta.env.BASE_URL + 'sw.js').catch(() => {}); });
}

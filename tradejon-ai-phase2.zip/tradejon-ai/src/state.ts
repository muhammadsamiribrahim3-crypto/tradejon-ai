import { store } from './lib/storage';

export type Level = 'Beginner' | 'Intermediate' | 'Pro';
export interface Alert { symbol: string; condition: 'above' | 'below'; target: number }
export interface Journal { symbol: string; direction: string; result: number; reason: string; date: string }
export interface Activity { msg: string; date: string }

const list = <T>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);
const bal = store.get<unknown>('balance', 10000);

export const state = {
  balance: typeof bal === 'number' && Number.isFinite(bal) ? bal : 10000,
  alerts: list<Alert>(store.get<unknown>('alerts', [])),
  journals: list<Journal>(store.get<unknown>('journals', [])),
  activity: list<Activity>(store.get<unknown>('activity', [])),
  level: store.get<Level>('level', 'Beginner'),
};
export const LIMITS = { alerts: 50, journals: 500, activity: 8 };

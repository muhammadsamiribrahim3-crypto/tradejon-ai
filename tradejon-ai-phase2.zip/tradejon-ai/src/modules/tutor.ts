import { $, showResult } from '../lib/dom';
import { assessStage } from '../lib/calc';
import { store } from '../lib/storage';
import { LESSONS } from '../data/lessons';
import { state, type Level } from '../state';

const LEVELS: Level[] = ['Beginner', 'Intermediate', 'Pro'];

function setLevel(l: string): void {
  state.level = (LEVELS as string[]).includes(l) ? (l as Level) : 'Beginner';
  store.set('level', state.level);
  document.querySelectorAll<HTMLElement>('[data-level]').forEach((x) => {
    const on = x.dataset.level === state.level;
    x.classList.toggle('active', on);
    x.setAttribute('aria-pressed', String(on));
  });
}

export function initTutor(): void {
  setLevel(state.level);
  document.querySelectorAll<HTMLElement>('[data-level]').forEach((b) => b.addEventListener('click', () => setLevel(b.dataset.level ?? 'Beginner')));
  $('lessonBtn').addEventListener('click', () => {
    const t = $<HTMLSelectElement>('topic').value;
    showResult('lessonResult', `${state.level} lesson — ${t}: ${LESSONS[t] ?? ''} This is a starter outline, not personalized financial advice.`);
  });
  $('assessBtn').addEventListener('click', () => {
    const r = assessStage(['q1', 'q2', 'q3'].map((id) => $<HTMLSelectElement>(id).value));
    showResult('assessResult', r
      ? `Your learning starting point: ${r.stage}. This is only a 3-question preview, not a reliable professional assessment. We will need a longer quiz and evidence of consistent execution for accurate placement.`
      : 'Please answer all three questions first.');
  });
}

import { $, num } from '../lib/dom';
import { fmt } from '../lib/format';
import { store } from '../lib/storage';
import { state } from '../state';
import { logActivity, refreshDashboard } from './dashboard';

export function initDemo(): void {
  $('applyPL').addEventListener('click', () => {
    const pl = num('demoPL');
    if (!Number.isFinite(pl)) { alert('Enter a valid simulated P/L amount.'); return; }
    state.balance = Math.max(0, state.balance + pl); // virtual balance cannot go below zero
    store.set('balance', state.balance);
    $<HTMLInputElement>('demoPL').value = '';
    logActivity(`Applied simulated P/L of $${fmt(pl)} to the demo wallet.`);
    refreshDashboard();
  });
  $('resetDemo').addEventListener('click', () => {
    state.balance = 10000;
    store.set('balance', state.balance);
    refreshDashboard();
  });
}

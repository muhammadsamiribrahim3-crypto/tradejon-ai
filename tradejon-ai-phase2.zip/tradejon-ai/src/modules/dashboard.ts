import { $, escapeHtml } from '../lib/dom';
import { fmt } from '../lib/format';
import { store } from '../lib/storage';
import { LIMITS, state } from '../state';

export function refreshDashboard(): void {
  $('balanceMetric').textContent = '$' + fmt(state.balance);
  $('demoBalance').textContent = '$' + fmt(state.balance);
  $('alertMetric').textContent = String(state.alerts.length);
  $('journalMetric').textContent = String(state.journals.length);
  const el = $('activityList');
  el.className = state.activity.length ? 'list' : 'empty';
  el.innerHTML = state.activity.length
    ? state.activity.map((a) => `<div class="rowline"><span>${escapeHtml(a.msg)}</span><span class="muted tiny">${escapeHtml(new Date(a.date).toLocaleDateString())}</span></div>`).join('')
    : 'No activity yet. Create a price alert or journal entry to get started.';
}

export function logActivity(msg: string): void {
  state.activity.unshift({ msg, date: new Date().toISOString() });
  state.activity = state.activity.slice(0, LIMITS.activity);
  store.set('activity', state.activity);
  refreshDashboard();
}

import { $, escapeHtml, num } from '../lib/dom';
import { fmt } from '../lib/format';
import { store } from '../lib/storage';
import { LIMITS, state } from '../state';
import { logActivity, refreshDashboard } from './dashboard';

function render(): void {
  const el = $('journalList');
  el.className = state.journals.length ? 'list' : 'empty';
  el.innerHTML = state.journals.length
    ? state.journals.slice().reverse().map((j) => `<div class="rowline"><div><b>${escapeHtml(j.symbol)}</b><small style="display:block;color:var(--muted);margin-top:4px">${escapeHtml(j.direction)} · ${escapeHtml(j.reason || 'No note')}</small></div><b class="${j.result >= 0 ? 'positive' : 'negative'}">${j.result >= 0 ? '+' : ''}$${fmt(Number(j.result))}</b></div>`).join('')
    : 'No trades logged yet.';
  refreshDashboard();
}

export function initJournal(): void {
  render();
  $('addJournal').addEventListener('click', () => {
    const symbol = $<HTMLInputElement>('jSymbol').value.trim().slice(0, 20);
    const result = num('jResult');
    if (!symbol || !Number.isFinite(result)) { alert('Enter a symbol and result.'); return; }
    if (state.journals.length >= LIMITS.journals) { alert(`Journal limit of ${LIMITS.journals} entries reached on this device.`); return; }
    const direction = $<HTMLSelectElement>('jDirection').value === 'Sell' ? 'Sell' : 'Buy';
    state.journals.push({ symbol, direction, result, reason: $<HTMLInputElement>('jReason').value.trim().slice(0, 300), date: new Date().toISOString() });
    store.set('journals', state.journals);
    ['jSymbol', 'jResult', 'jReason'].forEach((id) => { $<HTMLInputElement>(id).value = ''; });
    render();
    logActivity(`Added a journal entry for ${symbol}.`);
  });
  $('clearJournal').addEventListener('click', () => {
    if (!confirm('Delete all journal entries saved on this device?')) return;
    state.journals = [];
    store.set('journals', state.journals);
    render();
  });
}

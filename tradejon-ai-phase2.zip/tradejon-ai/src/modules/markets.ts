import { $, escapeHtml, num } from '../lib/dom';
import { store } from '../lib/storage';
import { LIMITS, state } from '../state';
import { logActivity, refreshDashboard } from './dashboard';

function render(): void {
  $('alertsList').className = state.alerts.length ? 'list' : 'empty';
  $('alertsList').innerHTML = state.alerts.length
    ? state.alerts.map((a, i) => `<div class="rowline"><div><b>${escapeHtml(a.symbol)}</b><small class="muted" style="display:block;margin-top:4px">${a.condition === 'above' ? 'Above' : 'Below'} ${escapeHtml(a.target)}</small></div><button class="secondary" data-remove-alert="${i}">Remove</button></div>`).join('')
    : 'No alerts saved yet.';
  refreshDashboard();
}

export function initMarkets(): void {
  render();
  $('addAlert').addEventListener('click', () => {
    const target = num('alertTarget');
    if (!Number.isFinite(target) || target <= 0) { alert('Enter a valid target price.'); return; }
    if (state.alerts.length >= LIMITS.alerts) { alert(`You can save up to ${LIMITS.alerts} local alerts.`); return; }
    const condition = $<HTMLSelectElement>('alertCondition').value === 'below' ? 'below' : 'above';
    const symbol = $<HTMLSelectElement>('alertSymbol').value;
    state.alerts.push({ symbol, condition, target });
    store.set('alerts', state.alerts);
    $<HTMLInputElement>('alertTarget').value = '';
    render();
    logActivity(`Saved a local alert rule for ${symbol}. Live monitoring is not enabled.`);
  });
  $('alertsList').addEventListener('click', (e) => {
    const b = (e.target as Element).closest<HTMLElement>('[data-remove-alert]');
    if (!b) return;
    state.alerts.splice(Number(b.dataset.removeAlert), 1);
    store.set('alerts', state.alerts);
    render();
  });
  $('clearAlerts').addEventListener('click', () => {
    if (!confirm('Remove all saved alerts?')) return;
    state.alerts = [];
    store.set('alerts', state.alerts);
    render();
  });
}

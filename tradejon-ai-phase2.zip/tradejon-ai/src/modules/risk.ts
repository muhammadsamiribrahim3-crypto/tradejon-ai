import { $, num, showResult } from '../lib/dom';
import { drawdownPct, riskAmount, stopDistance } from '../lib/calc';
import { fmt } from '../lib/format';
import { store } from '../lib/storage';

const CHECKS = [
  'Define entry, stop-loss and exit before trading', 'Know the money amount at risk before placing an order',
  'Check correlated positions and total exposure', 'Stop after reaching your daily loss limit',
  'Avoid revenge trading after a loss', 'Review high-impact news and firm restrictions',
];

export function initRisk(): void {
  $('calcRisk').addEventListener('click', () => {
    const amt = riskAmount(num('riskBalance'), num('riskPercent'));
    if (amt === null) { showResult('riskResult', 'Enter a positive balance and a risk percentage from 0 to 100.'); return; }
    const d = stopDistance(num('entry'), num('stop'));
    showResult('riskResult', `<b>Planned loss budget: $${fmt(amt)}</b><br>${d !== null
      ? 'Entry-to-stop distance: ' + d.toFixed(5) + '. Exact position size cannot be calculated safely without symbol contract specifications, pip/tick value and account currency.'
      : 'Add valid entry and stop-loss prices to view their distance.'}`, true);
  });

  $('calcDD').addEventListener('click', () => {
    const limit = num('ddLimit');
    const dd = drawdownPct(num('ddStart'), num('ddCurrent'));
    if (dd === null || !Number.isFinite(limit) || limit <= 0) { showResult('ddResult', 'Check your inputs.'); return; }
    showResult('ddResult', `Drawdown from starting balance: ${dd.toFixed(2)}%. Allowed limit: ${limit.toFixed(2)}%. ${dd >= limit ? 'Limit reached or breached in this simplified calculation.' : 'Below the configured limit in this simplified calculation.'} Exact prop rules may calculate drawdown differently.`);
  });

  const done = store.get<number[]>('checks', []);
  $('riskChecklist').innerHTML = CHECKS.map((x, i) => `<label class="rowline" style="justify-content:flex-start"><input type="checkbox" data-check="${i}" ${done.includes(i) ? 'checked' : ''}> <span>${x}</span></label>`).join('');
  $('riskChecklist').addEventListener('change', () => {
    const on = [...document.querySelectorAll<HTMLInputElement>('[data-check]')].filter((c) => c.checked).map((c) => Number(c.dataset.check));
    store.set('checks', on);
  });
}

import { $, num, showResult } from '../lib/dom';
import { store } from '../lib/storage';

interface PropSaved { daily: number; overall: number; trades: number; day: string }

export function initProp(): void {
  const p = store.get<PropSaved | null>('prop', null);
  if (p) {
    $<HTMLInputElement>('dailyLimit').value = String(p.daily);
    $<HTMLInputElement>('overallLimit').value = String(p.overall);
    $<HTMLInputElement>('tradesToday').value = p.day === new Date().toDateString() ? String(p.trades) : '0'; // resets each day
  }
  $('saveProp').addEventListener('click', () => {
    const v = { daily: num('dailyLimit'), overall: num('overallLimit'), trades: num('tradesToday') };
    if (![v.daily, v.overall, v.trades].every(Number.isFinite) || v.daily <= 0 || v.overall <= 0 || v.trades < 0) {
      showResult('propResult', 'Enter positive limits and a trades-today count of 0 or more.');
      return;
    }
    store.set('prop', { ...v, day: new Date().toDateString() });
    showResult('propResult', 'Saved these local reminders. No broker/account connection or automatic rule enforcement is active.');
  });
}

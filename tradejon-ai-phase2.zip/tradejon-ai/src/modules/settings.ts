import { $, showResult } from '../lib/dom';
import { store } from '../lib/storage';
import { LANGS, RTL } from '../data/languages';

function setLanguage(v: string): void {
  if (!LANGS.some((l) => l[0] === v)) v = 'en';
  store.set('language', v);
  $<HTMLSelectElement>('langTop').value = v;
  $<HTMLSelectElement>('langSettings').value = v;
  document.documentElement.dir = RTL.includes(v) ? 'rtl' : 'ltr'; // layout preview only; text is still English
}

export function initSettings(): void {
  for (const id of ['langTop', 'langSettings']) {
    const sel = $<HTMLSelectElement>(id);
    sel.innerHTML = LANGS.map(([c, n]) => `<option value="${c}">${n}</option>`).join('');
    sel.addEventListener('change', () => setLanguage(sel.value));
  }
  setLanguage(store.get('language', 'en'));
  $('loginBtn').addEventListener('click', () => alert('Sign-in is not connected in this prototype. Do not enter passwords here.'));
  $('authInfo').addEventListener('click', () => showResult('authResult', 'Production plan: use a trusted auth provider for email OTP and phone OTP; add rate limits, verification, secure sessions and recovery. TradingView: use only official supported sign-in/integration options. Never store provider passwords or API secrets in browser code.'));
}

// Local-only storage. Data stays in this browser and is lost if site data is cleared.
let warned = false;
export const store = {
  get<T>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem('tradejon_' + key);
      return raw === null ? fallback : (JSON.parse(raw) as T) ?? fallback;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown): boolean {
    try {
      localStorage.setItem('tradejon_' + key, JSON.stringify(value));
      return true;
    } catch {
      if (!warned) {
        warned = true;
        alert('This browser could not save your data (storage full or blocked). Changes may be lost.');
      }
      return false;
    }
  },
};

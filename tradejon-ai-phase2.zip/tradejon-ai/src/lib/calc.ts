// Pure calculation helpers (no DOM) so they can be unit-tested.
const ok = Number.isFinite;

export function riskAmount(balance: number, percent: number): number | null {
  if (!ok(balance) || !ok(percent) || balance <= 0 || percent < 0 || percent > 100) return null;
  return (balance * percent) / 100;
}
export function stopDistance(entry: number, stop: number): number | null {
  return ok(entry) && ok(stop) && entry > 0 && stop > 0 && entry !== stop ? Math.abs(entry - stop) : null;
}
export function drawdownPct(start: number, current: number): number | null {
  if (!ok(start) || !ok(current) || start <= 0 || current < 0) return null;
  return Math.max(0, ((start - current) / start) * 100);
}
export function assessStage(answers: string[]): { score: number; stage: string } | null {
  if (answers.some((a) => !a)) return null;
  const score = answers.reduce((n, a) => n + (a === 'yes' ? 2 : a === 'sometimes' || a === 'some' ? 1 : 0), 0);
  return { score, stage: score <= 2 ? 'Beginner' : score <= 4 ? 'Developing / Intermediate' : 'Provisional advanced' };
}

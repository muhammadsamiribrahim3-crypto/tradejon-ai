export function $<T extends HTMLElement = HTMLElement>(id: string): T {
  const el = document.getElementById(id);
  if (!el) throw new Error(`Missing element #${id}`);
  return el as T;
}
export const escapeHtml = (s: unknown): string =>
  String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] as string);
/** Reads a number input; returns NaN when empty or invalid. */
export const num = (id: string): number => {
  const v = $<HTMLInputElement>(id).value.trim();
  return v === '' ? NaN : Number(v);
};
export function showResult(id: string, content: string, html = false): void {
  const el = $(id);
  el.style.display = 'block';
  if (html) el.innerHTML = content;
  else el.textContent = content;
}

import { defineConfig } from 'vitest/config';

// base './' lets the app work from any sub-folder (GitHub Pages, Netlify, Cloudflare Pages).
export default defineConfig({
  base: './',
  server: { host: true },
  test: { environment: 'node', include: ['tests/**/*.test.ts'] },
});

# TradeJon AI — Phase 2 (Vite + TypeScript, PWA-ready)

Local-only prototype. No sign-in, live prices, AI, server alerts or order execution exist yet.

## Run
    npm install
    npm run dev          # development, auto-reloads
    npm test             # unit tests for calculators
    npm run build        # type-check + production build into dist/
    npm run preview      # serve dist/ (service worker + install prompt work here)

## Structure
    index.html            page markup
    src/main.ts           start-up
    src/router.ts         pages, #hash navigation, mobile menu
    src/state.ts          saved data shape + limits
    src/lib/              dom helpers, storage, pure calculators (tested)
    src/data/             lessons, languages
    src/modules/          one file per feature page
    src/styles.css        all styling
    public/               manifest, icons, sw.js, _headers (security headers for Netlify/Cloudflare Pages)
    tests/                Vitest tests

## Feature status
| Feature | Status |
|---|---|
| Navigation, calculators, journal, local alerts list, demo wallet, prop reminders | Working, frontend only, data stays in this browser |
| PWA install + offline fallback | Implemented; test on a production build |
| Language selector | Saves choice + RTL preview; NO translations yet |
| Auth, live data, AI tutor, server alerts, real demo engine | Not started |
